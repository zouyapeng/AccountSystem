# Processing empty hyperlinks

This test checks wheter empty hyperlinks still appear in the markdown result.

[](http://some.link)

[](http://some.link)

