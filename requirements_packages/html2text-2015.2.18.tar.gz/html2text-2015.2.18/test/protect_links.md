[foo](<http://im-a-very-very-very-very-very-very-very-very-very-very-
long/link.html>)

