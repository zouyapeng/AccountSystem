#  test doc

first issue

  * bit
  * _**bold italic**_
    * orange
    * apple
  * final

text to separate lists

  1. now with numbers
  2. the prisoner
    1. not an _italic number_
    2. a **bold human** being
  3. end

**bold**  
_italic_  
text with \_underscore but not \_italicized  

    
    
    def func(x):
      if x < 1:
        return 'a'
      return 'b'
          

Some `fixed width text` here  
_`italic fixed width text`_

2012\. Now that was a good year. So was 2011. That's all.

3.14159 is an approximation of pi.

\+ not + a list item

+foo

\- foo - bar

-foo 

not a header  
\--

not a hr  
  
\---  
\- - -

c:\tmp, \\\server\path, \\\_/, foo\bar, \#\\\#, \\\\\#

