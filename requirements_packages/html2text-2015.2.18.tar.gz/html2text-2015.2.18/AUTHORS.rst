``html2text`` was originally written by Aaron Swartz.

The AUTHORS/Contributors are (and/or have been):

* Aaron Swartz
* Yariv Barkan
* Alex Musayev
* Matěj Cepl
* Stefano Rivera
* Alireza Savand <alireza.savand@gmail.com>
* Ivan Gromov <summer.is.gone@gmail.com>
* Jocelyn Delalande <jdelalande@oasiswork.fr>
* Matt Dorn <matt.dorn@gmail.com>
* Miguel Tavares <mgontav@gmail.com>

Maintainer:

* Alireza Savand <alireza.savand@gmail.com>
