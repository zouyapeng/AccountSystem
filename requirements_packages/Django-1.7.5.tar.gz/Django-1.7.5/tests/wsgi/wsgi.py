# This is just to test finding, it doesn't have to be a real WSGI callable
application = object()
