NAME='forkptyrouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

REQUIRES = ['corerouter']

GCC_LIST = ['forkptyrouter']
