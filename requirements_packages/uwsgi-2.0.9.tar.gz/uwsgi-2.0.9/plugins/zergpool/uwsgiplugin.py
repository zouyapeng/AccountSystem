
NAME='zergpool'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['zergpool']
