NAME='rsyslog'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['rsyslog_plugin']
